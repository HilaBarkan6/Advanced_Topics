#include "Shell.h"
#include "Tank.h"

using namespace GameManager_209399021_208239152;

Shell::Shell(std::pair<int, int> loc, CanonDirection dir): GameObject(), location(loc), flying_direction(dir) {};

std::pair<int,int> Shell::getLocation() const { return location; }

void Shell::setLocation(std::pair<int, int> loc) { location = loc; }

std::pair<int, int> Shell::getNextLocation() const { return next_location; }

void Shell::setNextLocation(std::pair<int, int> next_loc){
    next_location = next_loc;
}

std::pair<int, int> Shell::getPrevLocation() const{
    return previous_location;
}

void Shell::setPrevLocation(std::pair<int, int> cur_location){
    previous_location = cur_location;
}

CanonDirection Shell::getFlyingDirection() const {
    return flying_direction;
}

void Shell::setFlyingDirection(CanonDirection direction) { flying_direction = direction; }